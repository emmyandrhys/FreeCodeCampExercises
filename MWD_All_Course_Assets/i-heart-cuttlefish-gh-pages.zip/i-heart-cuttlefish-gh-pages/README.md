I Heart Cuttlefish
==================

A little project for my Gymnasium class.
